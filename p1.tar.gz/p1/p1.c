/* Christopher Cardenas
* CS 3060 Summer 2024 Term 2
* Project 1
*/

#include <stdio.h>

int main(int argc, char *argv[]){
	printf("Christopher Cardenas: Project 1\n");

	for (int i=0; i< argc; i++) {
		printf("%s\n", argv[i]);
	}

	printf("%d\n", argc);

	return 0;
}
